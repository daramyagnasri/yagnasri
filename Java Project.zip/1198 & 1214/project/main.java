import com.fee.*;

public class main
{
	public static void main(String[] args)
	{
		LoginFrame f = new LoginFrame();
	}
}