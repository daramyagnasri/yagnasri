package com.fee;
public class FeeD
{
	int receipt_id;
	int ht_no;
	double fees;
	double paid;
	
	public int getReceipt_id()
	{
		return receipt_id;
	}
	public void setReceipt_id(int id)
	{
		receipt_id=id;
	}
	public int getHt_no()
	{
		return ht_no;
	}
	public void setHt_no(int no)
	{
		ht_no=no;
	}
	public double getFees()
	{
		return fees;
	}
	public void setFees(double amt)
	{
		fees=amt;
	}
	public double getPaid()
	{
		return paid;
	}
	public void setPaid(double amt)
	{
		paid=amt;
	}
	public double getDue()
	{
		return fees-paid;
	}
}