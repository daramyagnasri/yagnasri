package com.fee;
import javax.swing.*;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class dashboard implements ActionListener{
	JFrame frame;
	JLabel l1,l2,l3;
	JTextField tf1,tf2;
	JButton b1_view;
	JButton b2_delete;
	JButton b3_add;
	JButton b4_logout;
	FeeD acc=new FeeD();
	dashboard(){
		JFrame frame=new JFrame();
		JPanel p1_blue=new JPanel();
		JPanel p2_yellow=new JPanel();
		JPanel p3_green=new JPanel();
		p1_blue.setBackground(Color.blue);
		p1_blue.setBounds(0,0,200,461);
		p2_yellow.setBounds(200,40,500,150);
		p3_green.setBounds(200,190,500,50);
		b1_view=new JButton("View Fee Details");
		b1_view.setBackground(Color.BLUE);
		b1_view.setForeground(Color.WHITE);
		b1_view.setFocusable(false);
		b1_view.setLayout(new FlowLayout(FlowLayout.LEFT));
		b1_view.addActionListener(this);
		b2_delete=new JButton("Delete Student");
		b2_delete.setBackground(Color.BLUE);
		b2_delete.setForeground(Color.WHITE);
		b2_delete.setFocusable(false);
		b2_delete.addActionListener(this);
		b2_delete.setLayout(new FlowLayout(FlowLayout.CENTER));
		b3_add=new JButton("Fee Payment");
		b3_add.setBackground(Color.BLUE);
		b3_add.setForeground(Color.WHITE);
		b3_add.setFocusable(false);
		b3_add.addActionListener(this);
		
		b3_add.setLayout(new FlowLayout(FlowLayout.RIGHT));
		b4_logout=new JButton("Log out");
		b4_logout.setBackground(Color.BLUE);
		b4_logout.setForeground(Color.WHITE);
		b4_logout.setFocusable(false);
		b4_logout.addActionListener(this);
		ImageIcon img=new ImageIcon("pic1.jpeg");
		ImageIcon img2=new ImageIcon("pic2.jpeg");
		JLabel label=new JLabel("Fee Payment");
		JLabel label2=new JLabel("Online Fee Management");
		JLabel label3=new JLabel("WELCOME TO YOUR DASHBOARD");
		label.setHorizontalTextPosition(label.CENTER);
		label.setVerticalTextPosition(label.BOTTOM);
		label3.setHorizontalTextPosition(label3.CENTER);
		label3.setVerticalTextPosition(label3.BOTTOM);
		label.setForeground(Color.WHITE);
		label2.setForeground(Color.WHITE);
		label3.setForeground(Color.BLUE);
		label.setFont(new Font("Helvetica",Font.BOLD,20));
		label3.setFont(new Font("Helvetica",Font.BOLD,20));
		label.setIcon(img);
		label3.setIcon(img2);
		p1_blue.add(label);
		p1_blue.add(label2);
		p1_blue.add(b4_logout);
		p2_yellow.add(label3);
		p3_green.add(b1_view);
		p3_green.add(b2_delete);
		p3_green.add(b3_add);
		frame.add(p2_yellow);
		frame.add(p3_green);
		frame.setTitle("Dashboard");
		frame.setSize(700,500);
		frame.add(p1_blue);
		frame.setLayout(null);
		frame.setVisible(true);

}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==b3_add) {
			try
	        {
		String num7;
	           num7= JOptionPane.showInputDialog(null, "Enter Receipt id:", "Details", 2);
	           int num6 = Integer.parseInt(num7);
	           acc.setReceipt_id(num6);
    			String num;
	           num = JOptionPane.showInputDialog(null, "Enter Hall Tictek No:", "Details", 2);
	           int num1 = Integer.parseInt(num);
	           acc.setHt_no(num1);

			           String num2;
	           num2 = JOptionPane.showInputDialog(null, "Enter Total Fee:", "Fees", 2);
	           double num3 = Double.parseDouble(num2);
	           acc.setFees(num3);

			           String num4;
	           num4 = JOptionPane.showInputDialog(null, "Enter Fee paid:", "paid", 2);
	           double num5 = Double.parseDouble(num4);
	           acc.setPaid(num5);
	        }
	        catch(NumberFormatException | NullPointerException nfe1)
	        {
	            JOptionPane.showMessageDialog(null, nfe1, "Error", 2);
	        }
	    }
			  
		if(e.getSource()==b2_delete) {
			try
	           {
		String num;
		 num= JOptionPane.showInputDialog(null, "Enter Hall ticket number", "Delete Student", 1);
		int num1 = Integer.parseInt(num);				
		if(acc.getHt_no()==num1){
			
		 JOptionPane.showMessageDialog(null, num1+" Deleted successfully" , "Delete Student", 1);
		}
		else{
			 JOptionPane.showMessageDialog(null, num1+" Not found" , "Delete Student", 1);
		}
	           }
	           catch(NumberFormatException | NullPointerException ex)
	           {
	               JOptionPane.showMessageDialog(null, ex, "Error", 2);
	           }
		  
		}
		if(e.getSource()==b1_view) {
			try
		       {
					        	
			String msg="Receipt ID:"+acc.getReceipt_id()+"\n"+
					"Hall Ticket No:"+acc.getHt_no()+"\n"+
					"Total Fee:"+acc.getFees()+"\n"+
					"Fee Due:"+acc.getDue();
			 JOptionPane.showMessageDialog(null, "Details\n " + msg, "Student details", 1);
		       }
		       catch(NullPointerException npe)
		       {
		           JOptionPane.showMessageDialog(null, npe, "Error", 2);
		       }
		    }
		if(e.getSource()==b4_logout) {
			System.exit(0);
		}
			
		
	}
}