package com.fee;

public class Login {
String username;
String password;
public Login(){
username="meghana";
password="@123";
}
boolean validate( String username, String password) {
if(this.username.equalsIgnoreCase(username) &&
this.password.equals(password))
return true;
else
return false;
}
}